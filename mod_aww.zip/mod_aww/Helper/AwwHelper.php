<?php
/**
 * @package    aww
 *
 * @author     Rahul Saini heyrahulsaini@gmail.com
 * @copyright  [COPYRIGHT]
 * @license    [license]
 */

namespace Rahulsaini\Module\aww\Site\Helper;

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;

/**
 * Helper for mod_aww
 *
 */
class AwwHelper
{
// Registry $params
    public static function WriteDb()
    {    
        $db = Factory::getDbo();

        $input = 'yay';
        $entry = new stdClass();
        $entry->message = $input;

        $result = $db->insertObject('#__mod_aww', $profile);

        return $result;
    }
}