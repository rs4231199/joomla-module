<?php
/**
 * @package    aww
 *
 * @author     Rahul Saini heyrahulsaini@gmail.com
 * @copyright  [COPYRIGHT]
 * @license    [license]
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Helper\ModuleHelper;
use Joomla\Registry\Registry;

/**
 * Helper for mod_aww
 *
 */
class ModAwwHelper
{   
    public static function WriteDbAjax()
    {    
        $db = Factory::getContainer()->get('DatabaseDriver');
        
        $input = 'yay';
        $entry = new \stdClass;
        $entry->message = $input;

        $result = $db->insertObject('#__mod_aww', $entry);

        if($result) {
            return $result;
        }
        return false;
		
    }
}