/**
 * @copyright   [copyright]
 * @license     [license]
 */

 ((document, Joomla) => {
	'use strict';

	function ajax_call()
	{
		// request to the backend articles controlled is made because there is no front-end controller
		// which returns a JSON response
		Joomla.request({
		    url: 'administrator/index.php?option=com_content&task=articles.getQuickiconContent&format=json',
		    onSuccess: (response) => {
		     	alert("success: " + JSON.parse(response).success);
		    },
			onError: () => {
				alert("There is an error");
			}
		});

		
		// Joomla.request({
        //     url: 'index.php?option=com_ajax&module=aww&format=json&method=WriteDb',
		//     onSuccess: (response) => {
		//      	console.log("module aww => success: " + response);
		//     },
		// 	onError: () => {
		// 		console.log("module aww => ERROR");
		// 	}
        // });
	}

	document.addEventListener('DOMContentLoaded', () => {
		const cat_image = document.getElementById('mod_aww_cat_image');
		const form = document.getElementById('mod_aww_form');
		if(cat_image) {
			cat_image.addEventListener('click', function () {
				if(form.classList.contains('d-none'))
				{
					form.classList.remove('d-none');
				}
				else
				{
					form.classList.add('d-none');
				}
			});
		}

		document.getElementById('mod_aww_OK').addEventListener('click', ajax_call);
		
	});
})(document, Joomla);
