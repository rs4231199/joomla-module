<?php
/**
 * @package    aww
 *
 * @author     Rahul Saini heyrahulsaini@gmail.com
 * @copyright  [COPYRIGHT]
 * @license    [license]
 */

// No direct access to this file
defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;

require ModuleHelper::getLayoutPath('mod_aww', $params->get('layout', 'default'));