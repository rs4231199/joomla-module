<?php
/**
 * @package    aww
 *
 * @author     Rahul Saini heyrahulsaini@gmail.com
 * @copyright  [COPYRIGHT]
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;

echo HTMLHelper::_('image', 'mod_aww/cat-image.jpg', '', ['id' => 'mod_aww_cat_image'], true);
HTMLHelper::_('script', 'mod_aww/mod-aww-script.min.js', array('version' => 'auto', 'relative' => true));
?>

<div id='mod_aww_form' class='form-group d-none'>
    <input type='text' class='form-control' id='mod_aww_text_input' name='mod_aww_text_input'>
    <button type='button' id='mod_aww_OK' class='btn btn-primary'>OK</button>
</div>